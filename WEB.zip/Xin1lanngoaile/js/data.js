// ===== TRANSLATIONS =====
const i18n = {
  vi: {
    nav_home: "Trang chủ",
    nav_products: "Sản phẩm",
    nav_compare: "So sánh",
    nav_contact: "Liên hệ",
    nav_login: "Đăng nhập",
    nav_register: "Đăng ký",
    nav_logout: "Đăng xuất",
    hero_slogan: "Kiến tạo tương lai",
    hero_sub: "Xe điện thông minh – Trải nghiệm đẳng cấp thế giới",
    hero_cta1: "Khám phá",
    hero_cta2: "Đặt xe ngay",
    products_title: "Dòng xe VinFast",
    products_sub: "Bộ sưu tập xe điện VinFast – Tiên phong công nghệ xanh",
    btn_configure: "Cấu hình xe",
    btn_add_cart: "Thêm vào giỏ",
    btn_add_compare: "So sánh",
    cart_title: "Giỏ hàng",
    cart_empty: "Giỏ hàng trống",
    cart_total: "Tổng cộng",
    cart_checkout: "Thanh toán",
    cart_remove: "Xóa",
    cart_qty: "Số lượng",
    compare_title: "So sánh xe",
    compare_sub: "Chọn 2–3 xe để so sánh thông số",
    compare_select: "Chọn xe để so sánh",
    compare_btn: "So sánh ngay",
    compare_clear: "Xóa tất cả",
    compare_range: "Phạm vi",
    compare_power: "Công suất",
    compare_battery: "Pin",
    compare_seats: "Chỗ ngồi",
    compare_price: "Giá",
    compare_speed: "Tốc độ tối đa",
    compare_charge: "Sạc nhanh",
    config_title: "Cấu hình xe",
    config_color: "Màu xe",
    config_version: "Phiên bản",
    config_battery: "Gói pin",
    config_rent: "Thuê pin",
    config_buy: "Mua pin",
    config_price: "Giá dự kiến",
    config_order: "Đặt cọc",
    config_desc: "Mô tả",
    config_highlights: "Điểm nổi bật",
    config_specs: "Thông số kỹ thuật",
    config_seats: "Chỗ ngồi",
    config_top_speed: "Tốc độ tối đa",
    config_fast_charge: "Sạc nhanh (10→80%)",
    testdrive_title: "Lái thử xe",
    testdrive_sub: "Đăng ký lái thử – Trải nghiệm ngay hôm nay",
    testdrive_name: "Họ và tên",
    testdrive_phone: "Số điện thoại",
    testdrive_car: "Chọn xe",
    testdrive_date: "Ngày hẹn",
    testdrive_time: "Giờ hẹn",
    testdrive_submit: "Đăng ký lái thử",
    testdrive_success: "Đăng ký thành công! Chúng tôi sẽ liên hệ sớm.",
    auth_login: "Đăng nhập",
    auth_register: "Đăng ký",
    auth_name: "Họ và tên",
    auth_email: "Email",
    auth_password: "Mật khẩu",
    auth_confirm: "Xác nhận mật khẩu",
    auth_submit_login: "Đăng nhập",
    auth_submit_reg: "Tạo tài khoản",
    auth_have_acc: "Đã có tài khoản?",
    auth_no_acc: "Chưa có tài khoản?",
    auth_forgot: "Quên mật khẩu?",
    footer_about: "Giới thiệu",
    footer_policy: "Chính sách bảo mật",
    footer_terms: "Điều khoản sử dụng",
    footer_careers: "Tuyển dụng",
    footer_news: "Tin tức",
    footer_support: "Hỗ trợ",
    footer_contact: "Liên hệ",
    footer_slogan: "Kiến tạo tương lai – Thuần Việt – Tầm Thế giới",
    footer_copy: "© 2024 VinFast Auto. All rights reserved.",
    contact_title: "Liên hệ với chúng tôi",
    contact_sub: "Chúng tôi luôn sẵn sàng hỗ trợ bạn",
    contact_name: "Họ và tên",
    contact_email: "Email",
    contact_message: "Nội dung",
    contact_submit: "Gửi tin nhắn",
    contact_success: "Tin nhắn đã được gửi! Cảm ơn bạn.",
    toast_added: "Đã thêm vào giỏ hàng!",
    toast_removed: "Đã xóa khỏi giỏ hàng",
    toast_login_required: "Vui lòng đăng nhập để tiếp tục",
    toast_compare_max: "Tối đa 3 xe để so sánh",
    toast_compare_added: "Đã thêm vào danh sách so sánh",
    spec_range: "Phạm vi",
    spec_power: "Công suất",
    stat_cars: "Xe đã bán",
    stat_countries: "Quốc gia",
    stat_dealers: "Đại lý",
    stat_satisfaction: "Hài lòng",
    about_title: "Về VinFast",
    about_desc: "VinFast là thương hiệu ô tô điện tiên phong của Việt Nam, thuộc tập đoàn Vingroup. Với sứ mệnh mang lại xe điện thông minh, an toàn và thân thiện môi trường, VinFast đang vươn tầm ra thị trường quốc tế.",
    reviews_title: "Khách hàng nói gì",
    chat_support: "Hỗ trợ 24/7",
    chat_advise: "Tư vấn",
    nav_profile: "Hồ sơ",
    profile_title: "Thông tin cá nhân",
    profile_info: "Thông tin chung",
    profile_name: "Họ và tên",
    profile_email: "Email",
    profile_save: "Lưu thay đổi",
    profile_orders: "Lịch sử đơn hàng",
    profile_no_orders: "Chưa có đơn hàng nào."
  },
  en: {
    nav_home: "Home",
    nav_products: "Products",
    nav_compare: "Compare",
    nav_contact: "Contact",
    nav_login: "Login",
    nav_register: "Register",
    nav_logout: "Logout",
    hero_slogan: "Shape the Future",
    hero_sub: "Smart Electric Vehicles – World-Class Experience",
    hero_cta1: "Explore",
    hero_cta2: "Order Now",
    products_title: "VinFast Vehicles",
    products_sub: "VinFast Electric Vehicle Collection – Pioneering Green Technology",
    btn_configure: "Configure",
    btn_add_cart: "Add to Cart",
    btn_add_compare: "Compare",
    cart_title: "Cart",
    cart_empty: "Your cart is empty",
    cart_total: "Total",
    cart_checkout: "Checkout",
    cart_remove: "Remove",
    cart_qty: "Qty",
    compare_title: "Compare Vehicles",
    compare_sub: "Select 2–3 vehicles to compare specs",
    compare_select: "Select vehicle to compare",
    compare_btn: "Compare Now",
    compare_clear: "Clear All",
    compare_range: "Range",
    compare_power: "Power",
    compare_battery: "Battery",
    compare_seats: "Seats",
    compare_price: "Price",
    compare_speed: "Top Speed",
    compare_charge: "Fast Charge",
    config_title: "Configure Vehicle",
    config_color: "Color",
    config_version: "Version",
    config_battery: "Battery Package",
    config_rent: "Lease Battery",
    config_buy: "Own Battery",
    config_price: "Estimated Price",
    config_order: "Reserve Now",
    config_desc: "Description",
    config_highlights: "Highlights",
    config_specs: "Specifications",
    config_seats: "Seats",
    config_top_speed: "Top Speed",
    config_fast_charge: "Fast Charge (10→80%)",
    testdrive_title: "Test Drive",
    testdrive_sub: "Book a Test Drive – Experience Today",
    testdrive_name: "Full Name",
    testdrive_phone: "Phone Number",
    testdrive_car: "Select Vehicle",
    testdrive_date: "Date",
    testdrive_time: "Time",
    testdrive_submit: "Book Test Drive",
    testdrive_success: "Booking successful! We will contact you soon.",
    auth_login: "Login",
    auth_register: "Register",
    auth_name: "Full Name",
    auth_email: "Email",
    auth_password: "Password",
    auth_confirm: "Confirm Password",
    auth_submit_login: "Login",
    auth_submit_reg: "Create Account",
    auth_have_acc: "Already have an account?",
    auth_no_acc: "Don't have an account?",
    auth_forgot: "Forgot password?",
    footer_about: "About",
    footer_policy: "Privacy Policy",
    footer_terms: "Terms of Use",
    footer_careers: "Careers",
    footer_news: "News",
    footer_support: "Support",
    footer_contact: "Contact",
    footer_slogan: "Shape the Future – Proudly Vietnamese – World Class",
    footer_copy: "© 2024 VinFast Auto. All rights reserved.",
    contact_title: "Contact Us",
    contact_sub: "We are always ready to assist you",
    contact_name: "Full Name",
    contact_email: "Email",
    contact_message: "Message",
    contact_submit: "Send Message",
    contact_success: "Message sent! Thank you.",
    toast_added: "Added to cart!",
    toast_removed: "Removed from cart",
    toast_login_required: "Please login to continue",
    toast_compare_max: "Maximum 3 vehicles to compare",
    toast_compare_added: "Added to compare list",
    spec_range: "Range",
    spec_power: "Power",
    stat_cars: "Cars Sold",
    stat_countries: "Countries",
    stat_dealers: "Dealers",
    stat_satisfaction: "Satisfaction",
    about_title: "About VinFast",
    about_desc: "VinFast is Vietnam's pioneering electric vehicle brand under the Vingroup conglomerate. With a mission to deliver smart, safe, and eco-friendly electric vehicles, VinFast is expanding globally.",
    reviews_title: "What Customers Say",
    chat_support: "24/7 Support",
    chat_advise: "Live Chat",
    nav_profile: "Profile",
    profile_title: "Personal Profile",
    profile_info: "General Info",
    profile_name: "Full Name",
    profile_email: "Email",
    profile_save: "Save Changes",
    profile_orders: "Order History",
    profile_no_orders: "No orders yet."
  }
};

// ===== VEHICLE DATA =====
const VEHICLES = [
  {
    id: "vf3",
    name: "VF 3",
    image: "images/vf3.png",
    basePrice: 235000000,
    priceLabel: "235.000.000 đ",
    range: "210 km",
    power: "42 mã lực",
    powerEn: "42 hp",
    battery: "15 kWh",
    seats: 4,
    topSpeed: "100 km/h",
    fastCharge: "30 phút",
    category: "Mini EV",
    desc_vi: "VinFast VF 3 – Xe điện mini đô thị hoàn hảo cho thế hệ trẻ. Thiết kế nhỏ gọn, cá tính với nội thất hiện đại và hệ thống hỗ trợ lái thông minh. Phù hợp di chuyển nội thành, dễ đỗ xe và tiết kiệm chi phí vận hành tối đa.",
    desc_en: "VinFast VF 3 – The perfect mini urban EV for the young generation. Compact and bold design with a modern interior and smart driver assistance system. Ideal for city commuting, easy parking and maximum cost savings.",
    highlights_vi: ["Thiết kế nhỏ gọn, cá tính", "Phù hợp đô thị, dễ đậu xe", "Chi phí vận hành cực thấp", "Hệ thống ADAS thông minh"],
    highlights_en: ["Compact & bold design", "Urban-ready, easy parking", "Ultra-low running cost", "Smart ADAS system"],
    colors: [
      { name: "Trắng / White", hex: "#F5F5F5", img: "https://product.hstatic.net/200000960063/product/vf_3_infinity_blanc_with_wheel_cover__5__182200ce0dfa4195a4e1f88ef6229906_master.png" },
      { name: "Hồng / Pink", hex: "#d4229fff", img: "https://vinfastphantrongtue.com/wp-content/uploads/2024/05/Iris-Berry-1.png" },
      { name: "Xanh / Blue", hex: "#1A4C8B", img: "https://vinfastphantrongtue.com/wp-content/uploads/2024/05/Electric-Blue-1.png" },
      { name: "Vàng / Yellow", hex: "#dbde26ff", img: "https://vinfastotothanhhoa.vn/OTO3602400618/files/san_pham/VF3/mau_xe/vang.webp" },
    ],
    versions: [
      { name: "Eco", price: 0, desc_vi: "Phiên bản tiêu chuẩn với đầy đủ tính năng cơ bản, lý tưởng cho di chuyển hàng ngày.", desc_en: "Standard trim with all essential features, ideal for everyday city driving." },
      { name: "Plus", price: 15000000, desc_vi: "Nâng cấp màn hình lớn hơn, ghế chỉnh điện, sạc không dây và thêm nhiều tính năng tiện ích.", desc_en: "Upgraded with larger screen, power-adjustable seats, wireless charging and more convenience features." },
    ],
    battery_options: [
      { label_vi: "Thuê pin (-20tr/năm)", label_en: "Lease Battery (-20M/yr)", price: -20000000 },
      { label_vi: "Mua pin", label_en: "Own Battery", price: 0 },
    ]
  },
  {
    id: "vf5",
    name: "VF 5",
    image: "images/vf5.png",
    basePrice: 458000000,
    priceLabel: "458.000.000 đ",
    range: "326 km",
    power: "100 mã lực",
    powerEn: "100 hp",
    battery: "37.23 kWh",
    seats: 5,
    topSpeed: "140 km/h",
    fastCharge: "35 phút",
    category: "Mini SUV",
    desc_vi: "VinFast VF 5 – Crossover điện đa năng, kết hợp hoàn hảo giữa phong cách thể thao và tính thực dụng. Cabin rộng rãi cho 5 người, hệ thống giải trí tiên tiến và khả năng vận hành linh hoạt trên mọi địa hình đô thị.",
    desc_en: "VinFast VF 5 – A versatile electric crossover combining sporty style and practicality. Spacious 5-seat cabin, advanced infotainment system, and agile performance for all urban terrains.",
    highlights_vi: ["Thiết kế crossover thể thao", "Cabin rộng rãi 5 chỗ", "Hành trình 326 km/sạc", "Camera 360° toàn cảnh"],
    highlights_en: ["Sporty crossover design", "Spacious 5-seat cabin", "326 km range per charge", "360° surround camera"],
    colors: [
      { name: "Đỏ / Red", hex: "#C0392B", img: "https://static-cms-prod.vinfastauto.ph/statics/2024-05/vf5plus_sunsetorange__whiteroof_backcopyw1.webp" },
      { name: "Trắng / White", hex: "#F5F5F5", img: "https://vinfast-vn.vn/wp-content/uploads/2023/10/vinfast-vf5-white.png" },
      { name: "Xanh / Blue", hex: "#1A4C8B", img: "https://vinfastautomienbac.com/wp-content/uploads/2025/02/vinfast-vf-5-240724-c-09.jpg" },
      { name: "Đen / Black", hex: "#1A1A1A", img: "https://vinfastcarhanoi.com/wp-content/uploads/2025/02/vinfast-vf5-6.png" },
    ],
    versions: [
      { name: "Eco", price: 0, desc_vi: "Trang bị tiêu chuẩn đầy đủ với màn hình cảm ứng 10 inch và điều hòa tự động.", desc_en: "Standard equipment with 10-inch touchscreen and automatic climate control." },
      { name: "Plus", price: 25000000, desc_vi: "Bổ sung camera 360°, ghế da cao cấp, sạc không dây và cửa sổ trời toàn cảnh.", desc_en: "Adds 360° camera, premium leather seats, wireless charging and panoramic sunroof." },
    ],
    battery_options: [
      { label_vi: "Thuê pin (-20tr/năm)", label_en: "Lease Battery (-20M/yr)", price: -20000000 },
      { label_vi: "Mua pin", label_en: "Own Battery", price: 0 },
    ]
  },
  {
    id: "vf6",
    name: "VF 6",
    image: "images/vf6.png",
    basePrice: 675000000,
    priceLabel: "675.000.000 đ",
    range: "381 km",
    power: "201 mã lực",
    powerEn: "201 hp",
    battery: "59.6 kWh",
    seats: 5,
    topSpeed: "155 km/h",
    fastCharge: "35 phút",
    category: "Compact SUV",
    desc_vi: "VinFast VF 6 – SUV điện cỡ C hiện đại với công suất 201 mã lực, mang đến trải nghiệm lái đầy cảm xúc. Nội thất rộng rãi, màn hình 15.6 inch, hệ thống lái trợ lực điện và loạt công nghệ an toàn ADAS tiên tiến nhất.",
    desc_en: "VinFast VF 6 – A modern C-segment electric SUV with 201 hp, delivering an exhilarating driving experience. Spacious interior, 15.6-inch screen, electric power steering, and the most advanced ADAS safety technologies.",
    highlights_vi: ["201 mã lực mạnh mẽ", "Màn hình 15.6 inch rộng lớn", "381 km hành trình/sạc", "17 tính năng an toàn ADAS"],
    highlights_en: ["201 hp powerful performance", "15.6-inch widescreen display", "381 km range per charge", "17 ADAS safety features"],
    colors: [
      { name: "Trắng / White", hex: "#F5F5F5", img: "https://vinfast-cars.vn/wp-content/uploads/2024/10/vinfast-vf6-trang.png" },
      { name: "Xanh lá / Green", hex: "#10d347ff", img: "https://vinfast3sthanhhoa.com/wp-content/uploads/2023/09/vf6-mau-xanh-reu-1110x1032-600x600-1.jpg" },
      { name: "Xanh / Blue", hex: "#3d0cceff", img: "https://vinfastat-hcm.com/wp-content/uploads/2024/03/vf6.png" },
      { name: "Đen / Black", hex: "#1A1A1A", img: "https://danang-vinfast.com/wp-content/uploads/2024/06/vf6-neptune-grey.png" },
    ],
    versions: [
      { name: "Eco", price: 0, desc_vi: "Trang bị những tính năng tiện nghi hiện đại, phù hợp để trải nghiệm xe điện lần đầu.", desc_en: "Equipped with modern comfort features, perfect for first-time EV owners." },
      { name: "Plus", price: 30000000, desc_vi: "Nâng cấp ghế da, cửa sổ trời toàn cảnh và hệ thống âm thanh Harman cao cấp.", desc_en: "Upgraded with leather seats, panoramic sunroof and premium Harman audio system." },
      { name: "Premium", price: 60000000, desc_vi: "Trọn gói cao cấp: đèn Matrix LED, sạc không dây, lái tự động trên đường cao tốc.", desc_en: "Full premium package: Matrix LED lights, wireless charging, highway autopilot." },
    ],
    battery_options: [
      { label_vi: "Thuê pin (-20tr/năm)", label_en: "Lease Battery (-20M/yr)", price: -20000000 },
      { label_vi: "Mua pin", label_en: "Own Battery", price: 0 },
    ]
  },
  {
    id: "vf7",
    name: "VF 7",
    image: "images/vf7.png",
    basePrice: 850000000,
    priceLabel: "850.000.000 đ",
    range: "431 km",
    power: "348 mã lực",
    powerEn: "348 hp",
    battery: "75.3 kWh",
    seats: 5,
    topSpeed: "197 km/h",
    fastCharge: "32 phút",
    category: "Coupe SUV",
    desc_vi: "VinFast VF 7 – Coupe SUV điện thể thao mạnh mẽ với 348 mã lực dual motor, tăng tốc 0–100 km/h chỉ trong 5.9 giây. Thiết kế fastback độc đáo, nội thất sport cao cấp và hàng loạt công nghệ lái tự động thế hệ mới.",
    desc_en: "VinFast VF 7 – A powerful electric sport coupe SUV with 348 hp dual motor, accelerating 0–100 km/h in just 5.9 seconds. Unique fastback design, premium sport interior and next-gen autonomous driving technologies.",
    highlights_vi: ["348 mã lực động cơ kép", "0–100 km/h trong 5.9 giây", "Thiết kế Coupe SUV độc đáo", "Lái tự động Level 2+"],
    highlights_en: ["348 hp dual motor", "0–100 km/h in 5.9 seconds", "Unique Coupe SUV design", "Level 2+ Autopilot"],
    colors: [
      { name: "Đen / Black", hex: "#1A1A1A", img: "https://danang-vinfast.com/wp-content/uploads/2025/11/vf7-jet-black.webp" },
      { name: "Trắng / White", hex: "#F5F5F5", img: "https://vinfastotosaigon.com/OTO3602400600/files/mau_xe/VF7/product_CE18.webp" },
      { name: "Đỏ / Red", hex: "#C0392B", img: "https://bizweb.dktcdn.net/100/514/927/products/d7e6ad2f-ff78-40fc-9675-d03c35e23e97.png?v=1770951383273" },
      { name: "Bạc / Silver", hex: "#9B9B9B", img: "https://vinfast-sonla.com/wp-content/uploads/2024/08/tai-xuong-2.png" },
    ],
    versions: [
      { name: "Eco", price: 0, desc_vi: "Động cơ đơn 201 mã lực, đầy đủ trang bị thể thao và các tính năng an toàn chủ động.", desc_en: "Single motor 201 hp, full sport equipment and active safety features." },
      { name: "Plus", price: 40000000, desc_vi: "Động cơ kép 348 mã lực, thêm ghế thể thao, hệ thống âm thanh 13 loa Harman Kardon.", desc_en: "Dual motor 348 hp, sport seats added, 13-speaker Harman Kardon sound system." },
      { name: "Premium", price: 90000000, desc_vi: "Trọn gói cao cấp nhất: đèn Matrix LED, HUD, lái tự động cao tốc, nội thất Alcantara.", desc_en: "Ultimate premium package: Matrix LED, HUD, highway autopilot, Alcantara interior." },
    ],
    battery_options: [
      { label_vi: "Thuê pin (-20tr/năm)", label_en: "Lease Battery (-20M/yr)", price: -20000000 },
      { label_vi: "Mua pin", label_en: "Own Battery", price: 0 },
    ]
  },
  {
    id: "vf8",
    name: "VF 8",
    image: "images/vf8.png",
    basePrice: 1057000000,
    priceLabel: "1.057.000.000 đ",
    range: "471 km",
    power: "402 mã lực",
    powerEn: "402 hp",
    battery: "87.7 kWh",
    seats: 5,
    topSpeed: "200 km/h",
    fastCharge: "35 phút",
    category: "Midsize SUV",
    desc_vi: "VinFast VF 8 – SUV điện hạng D hàng đầu với 402 mã lực và hành trình lên đến 471 km. Được trang bị hệ thống lái tự động VinAI tiên tiến, màn hình trung tâm 15.6 inch, nội thất rộng rãi sang trọng và chuẩn an toàn 5 sao NHTSA.",
    desc_en: "VinFast VF 8 – A top-tier D-segment electric SUV with 402 hp and up to 471 km range. Equipped with advanced VinAI autopilot, 15.6-inch center display, spacious luxury interior and 5-star NHTSA safety rating.",
    highlights_vi: ["402 mã lực – tăng tốc mạnh mẽ", "471 km hành trình/sạc", "Lái tự động VinAI", "Đạt chuẩn 5 sao NHTSA"],
    highlights_en: ["402 hp – powerful acceleration", "471 km range per charge", "VinAI autonomous driving", "5-star NHTSA safety rating"],
    colors: [
      { name: "Xanh / Navy", hex: "#1A3C6B", img: "https://vinfastphantrongtue.com/wp-content/uploads/2023/09/44.png" },
      { name: "Trắng / White", hex: "#F5F5F5", img: "https://ninhbinhvinfast.vn/wp-content/uploads/2025/03/img-CE18.webp" },
      { name: "Đen / Black", hex: "#1A1A1A", img: "https://vinfast-hanam.com.vn/wp-content/uploads/2025/03/img-CE11-1.webp" },
      { name: "Đỏ / Red", hex: "#ef1010ff", img: "https://vinfastthinhcuong.com.vn/wp-content/uploads/2025/06/vf8.png" },
    ],
    versions: [
      { name: "Eco", price: 0, desc_vi: "Phiên bản tiêu chuẩn với động cơ RWD 260 mã lực, đầy đủ trang bị an toàn và tiện nghi hiện đại.", desc_en: "Standard trim with 260 hp RWD motor, full safety and modern comfort equipment." },
      { name: "Plus", price: 50000000, desc_vi: "Nâng cấp AWD 402 mã lực, ghế da Nappa, cửa sổ trời toàn cảnh và hệ thống lái trợ lực điện nâng cao.", desc_en: "Upgrade to AWD 402 hp, Nappa leather seats, panoramic sunroof and advanced electric power steering." },
      { name: "Premium", price: 120000000, desc_vi: "Đỉnh cao của dòng VF 8: HUD, lái tự động thế hệ mới VinAI, 9 camera, nội thất Alcantara cao cấp.", desc_en: "The pinnacle of VF 8: HUD, next-gen VinAI autopilot, 9 cameras, premium Alcantara interior." },
    ],
    battery_options: [
      { label_vi: "Thuê pin (-20tr/năm)", label_en: "Lease Battery (-20M/yr)", price: -20000000 },
      { label_vi: "Mua pin", label_en: "Own Battery", price: 0 },
    ]
  },
  {
    id: "vf9",
    name: "VF 9",
    image: "images/vf9.png",
    basePrice: 1499000000,
    priceLabel: "1.499.000.000 đ",
    range: "568 km",
    power: "408 mã lực",
    powerEn: "408 hp",
    battery: "123 kWh",
    seats: 7,
    topSpeed: "200 km/h",
    fastCharge: "35 phút",
    category: "Full-size SUV",
    desc_vi: "VinFast VF 9 – SUV điện 7 chỗ hạng sang đỉnh cao với 408 mã lực và phạm vi ấn tượng 568 km. Không gian 3 hàng ghế rộng rãi như phòng khách di động, trang bị hệ thống giải trí hàng ghế sau, trần kính toàn cảnh và hơn 30 tính năng ADAS.",
    desc_en: "VinFast VF 9 – A pinnacle 7-seat luxury electric SUV with 408 hp and an impressive 568 km range. Three-row spacious cabin like a moving living room, rear entertainment system, panoramic glass roof and over 30 ADAS features.",
    highlights_vi: ["7 chỗ rộng rãi – 3 hàng ghế", "568 km hành trình/sạc", "Giải trí hàng ghế sau", "30+ tính năng ADAS"],
    highlights_en: ["Spacious 7 seats – 3 rows", "568 km range per charge", "Rear seat entertainment", "30+ ADAS features"],
    colors: [
      { name: "Trắng / White", hex: "#F5F5F5", img: "https://vinfastquangngai.com.vn/wp-content/uploads/2024/08/Infinity-Blanc.webp" },
      { name: "Cam / Orange", hex: "#c34a0dff", img: "https://vinfastvinh.net.vn/images/detailed/12/img-CE1A.png" },
      { name: "Đen / Black", hex: "#1A1A1A", img: "https://www.vinfastmiennam.vn/images/imgs/images/vf9-eco-den.png" },
      { name: "Xanh / Green", hex: "#2bee12ff", img: "https://vinfastautodongnai.com/wp-content/uploads/2023/10/img-CE1H.png" },
    ],
    versions: [
      { name: "Eco", price: 0, desc_vi: "Phiên bản cơ bản 7 chỗ, đầy đủ tiện nghi cao cấp với động cơ AWD 408 mã lực.", desc_en: "Base 7-seat trim, full luxury amenities with AWD 408 hp motor." },
      { name: "Plus", price: 70000000, desc_vi: "Thêm ghế hàng 2 chỉnh điện massage, màn hình hàng sau, rèm che nắng điện.", desc_en: "Adds power massage 2nd-row seats, rear screens, electric sunshades." },
      { name: "Premium", price: 150000000, desc_vi: "Tối thượng sang trọng: nội thất Nappa toàn bộ, hệ thống loa Bose 19 loa, lái tự động hoàn toàn.", desc_en: "Ultimate luxury: full Nappa interior, 19-speaker Bose system, full autopilot." },
    ],
    battery_options: [
      { label_vi: "Thuê pin (-20tr/năm)", label_en: "Lease Battery (-20M/yr)", price: -20000000 },
      { label_vi: "Mua pin", label_en: "Own Battery", price: 0 },
    ]
  }
];

// ===== FORMAT CURRENCY =====
function formatPrice(num) {
  return num.toLocaleString('vi-VN') + ' đ';
}

// ===== STATE MANAGEMENT =====
const AppState = {
  lang: localStorage.getItem('vf_lang') || 'vi',
  user: JSON.parse(localStorage.getItem('vf_user') || 'null'),
  cart: JSON.parse(localStorage.getItem('vf_cart') || '[]'),
  compareList: JSON.parse(localStorage.getItem('vf_compare') || '[]'),

  setLang(lang) {
    this.lang = lang;
    localStorage.setItem('vf_lang', lang);
    applyTranslations();
  },
  setUser(user) {
    this.user = user;
    localStorage.setItem('vf_user', JSON.stringify(user));
  },
  clearUser() {
    this.user = null;
    localStorage.removeItem('vf_user');
    localStorage.removeItem('vf_session');
  },
  saveCart() {
    localStorage.setItem('vf_cart', JSON.stringify(this.cart));
  },
  addToCart(vehicle, color, version, batteryOpt, qty = 1) {
    const existing = this.cart.find(item =>
      item.id === vehicle.id && item.color === color.name &&
      item.version === version.name && item.battery === batteryOpt.label_vi
    );
    if (existing) {
      existing.qty += qty;
    } else {
      const price = vehicle.basePrice + version.price + batteryOpt.price;
      this.cart.push({
        id: vehicle.id,
        name: vehicle.name,
        image: vehicle.image,
        color: color.name,
        colorHex: color.hex,
        version: version.name,
        battery: batteryOpt.label_vi,
        batteryEn: batteryOpt.label_en,
        unitPrice: price,
        qty
      });
    }
    this.saveCart();
    updateCartUI();
    showToast(t('toast_added'));
  },
  removeFromCart(index) {
    this.cart.splice(index, 1);
    this.saveCart();
    updateCartUI();
    showToast(t('toast_removed'));
  },
  updateQty(index, qty) {
    if (qty < 1) return;
    this.cart[index].qty = qty;
    this.saveCart();
    updateCartUI();
  },
  addToCompare(vehicleId) {
    if (this.compareList.includes(vehicleId)) return;
    if (this.compareList.length >= 3) {
      showToast(t('toast_compare_max'));
      return;
    }
    this.compareList.push(vehicleId);
    localStorage.setItem('vf_compare', JSON.stringify(this.compareList));
    showToast(t('toast_compare_added'));
    updateCompareBar();
  },
  clearCompare() {
    this.compareList = [];
    localStorage.setItem('vf_compare', JSON.stringify([]));
    updateCompareBar();
  }
};

// ===== TRANSLATION HELPER =====
function t(key) {
  return i18n[AppState.lang][key] || key;
}

function applyTranslations() {
  document.querySelectorAll('[data-i18n]').forEach(el => {
    const key = el.getAttribute('data-i18n');
    if (i18n[AppState.lang][key]) {
      el.textContent = i18n[AppState.lang][key];
    }
  });
  document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
    const key = el.getAttribute('data-i18n-placeholder');
    if (i18n[AppState.lang][key]) {
      el.placeholder = i18n[AppState.lang][key];
    }
  });
  // Update lang toggle button
  const langBtn = document.getElementById('lang-toggle');
  if (langBtn) langBtn.textContent = AppState.lang === 'vi' ? 'EN' : 'VI';
  // Re-render dynamic sections
  if (typeof renderProducts === 'function') renderProducts();
  if (typeof renderCart === 'function') renderCart();
  if (typeof updateUserUI === 'function') updateUserUI();
}

// ===== TOAST NOTIFICATION =====
function showToast(msg, type = 'success') {
  const existing = document.getElementById('vf-toast');
  if (existing) existing.remove();
  const toast = document.createElement('div');
  toast.id = 'vf-toast';
  toast.className = `vf-toast vf-toast--${type}`;
  toast.textContent = msg;
  document.body.appendChild(toast);
  setTimeout(() => toast.classList.add('show'), 10);
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.remove(), 400);
  }, 3000);
}

// ===== UPDATE CART BADGE =====
function updateCartBadge() {
  const badge = document.getElementById('cart-badge');
  if (badge) {
    const count = AppState.cart.reduce((s, i) => s + i.qty, 0);
    badge.textContent = count;
    badge.style.display = count > 0 ? 'flex' : 'none';
  }
}
